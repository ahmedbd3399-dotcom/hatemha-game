# 🔥 حطّمها — PWA

لعبة ألغاز بلوكات عربية جاهزة للنشر على GitHub Pages والتثبيت كتطبيق PWA.

## رفعها على GitHub

1. أنشئ Repository جديد.
2. ارفع **كل محتويات هذا المجلد** إلى جذر الـRepository.
3. من:
   **Settings → Pages**
4. اختر:
   **Deploy from a branch**
5. اختر الفرع `main` والمجلد `/ (root)`.
6. احفظ وانتظر نشر الموقع.

## مهم
يجب أن تكون اللعبة على HTTPS حتى تعمل خدمة الـService Worker والتثبيت كـPWA بشكل صحيح. GitHub Pages يوفر HTTPS.

## الملفات
- `index.html` — اللعبة.
- `manifest.json` — تعريف التطبيق.
- `service-worker.js` — العمل بدون إنترنت والتخزين المؤقت.
- `icons/icon-192.png` — أيقونة PWA.
- `icons/icon-512.png` — أيقونة PWA.
- `404.html` — صفحة احتياطية لـGitHub Pages.

## بعد النشر
افتح رابط GitHub Pages من Chrome على Android، ثم اختر:
**إضافة إلى الشاشة الرئيسية / تثبيت التطبيق**.

## تحديث اللعبة
عند تغيير ملفات اللعبة، غيّر رقم `CACHE_NAME` في `service-worker.js`، مثل:
`hatemha-v2`
حتى تصل النسخة الجديدة للمستخدمين.
